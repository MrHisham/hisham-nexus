Hisham Nexus Integrated Governance Package
Created: 2026-06-12

Main files:
- 01_Governance_Manual/Hisham_Nexus_Integrated_Governance_Manual.docx
- 01_Governance_Manual/Hisham_Nexus_Integrated_Governance_Manual.pdf
- 02_Registers_and_Logs/Hisham_Nexus_Integrated_Governance_Registers.xlsx
- 03_Implementation_Templates/*.md
- 04_Website_Statements/Hisham_Nexus_Website_Governance_Statement.md

Important: This package is a practical, lightweight governance system. It is not a certificate and should not be represented as ISO certification.
