# HN-FRM-005 Annual Self-Audit Checklist

**Audit period:**  
**Auditor:**  
**Date:**  

| Area | Question | Status | Evidence | Action |
|---|---|---|---|---|
| Website claims | Are claims accurate and not overstated? | C / NC / OFI | | |
| Project control | Are scopes, risks, and deliverable reviews recorded? | C / NC / OFI | | |
| AI ethics | Is AI use controlled and reviewed? | C / NC / OFI | | |
| Security | Are client files protected and access controlled? | C / NC / OFI | | |
| Privacy | Is sensitive data minimized and retained only as needed? | C / NC / OFI | | |
| Complaints | Are complaints/feedback recorded and acted on? | C / NC / OFI | | |
| Knowledge | Are templates current and lessons learned captured? | C / NC / OFI | | |
