# HN-FRM-001 Project Intake and Risk Checklist

**Client / Project:**  
**Date:**  
**Service area:** Research / AI / Quality / Regulatory Writing / Training / Custom Resource  

## 1. Project Fit
- What is the objective?
- What is the intended use?
- Who is the audience?
- What is the expected deliverable?
- What is outside scope?

## 2. Inputs
- Client materials received:
- Missing information:
- Data sensitivity: Public / Internal / Client Confidential / Sensitive-Restricted

## 3. Risk Review
| Risk | Level | Control | Decision |
|---|---|---|---|
| Unclear scope | Low/Medium/High | | Accept / Clarify / Decline |
| Confidential data | Low/Medium/High | | Accept / Clarify / Decline |
| AI use risk | Low/Medium/High | | Accept / Clarify / Decline |
| Deadline risk | Low/Medium/High | | Accept / Clarify / Decline |
| Regulatory/professional boundary | Low/Medium/High | | Accept / Clarify / Decline |

## 4. Acceptance Decision
Accepted / Accepted with conditions / Declined

**Notes:**
