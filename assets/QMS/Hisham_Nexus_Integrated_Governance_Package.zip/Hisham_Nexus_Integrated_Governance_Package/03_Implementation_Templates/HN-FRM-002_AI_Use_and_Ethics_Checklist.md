# HN-FRM-002 AI Use and Ethics Checklist

**Project:**  
**Date:**  

## AI Use Purpose
- [ ] Ideation / outline
- [ ] Drafting support
- [ ] Editing / grammar
- [ ] Summarization
- [ ] Data or document review support
- [ ] Image or slide support
- [ ] Other: 

## Required Checks
- [ ] No confidential or sensitive client data entered into public AI tools without approval.
- [ ] AI output reviewed by a human.
- [ ] Scientific, regulatory, or technical claims checked.
- [ ] References and citations verified.
- [ ] AI did not fabricate data, evidence, or conclusions.
- [ ] Disclosure made if required by client, institution, journal, or policy.

**Decision:** Safe to use / Use with limitations / Do not use
