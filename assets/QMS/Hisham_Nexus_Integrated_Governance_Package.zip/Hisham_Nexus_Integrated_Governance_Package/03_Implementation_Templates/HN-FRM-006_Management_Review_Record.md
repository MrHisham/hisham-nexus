# HN-FRM-006 Management Review Record

**Review date:**  
**Period covered:**  

## Inputs
- Projects completed:
- Client feedback / satisfaction:
- Complaints / CAPA:
- Key risks and opportunities:
- Security/privacy incidents:
- AI use concerns:
- Resource or competence needs:
- Template/resource updates:

## Outputs
- Decisions made:
- Actions assigned:
- Target dates:
- Updates needed to policies, website, templates, or services:
