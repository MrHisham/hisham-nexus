Hisham Nexus Quality Manual Lite Package

Files included:
1. Quality_Manual/Hisham_Nexus_Quality_Manual_Lite.docx
2. Quality_Manual/Hisham_Nexus_Quality_Manual_Lite.pdf
3. Implementation_Templates/Project_Intake_and_Risk_Checklist.md
4. Implementation_Templates/Deliverable_Review_Checklist.md
5. Implementation_Templates/NC_Complaint_CAPA_Record.md
6. Implementation_Templates/Management_Review_Record.md
7. Implementation_Templates/Website_Quality_Statement.txt

Use:
- Approve the manual as HN-QM-001 v1.0.
- Start using the intake and deliverable review checklists for all new projects.
- Do not claim ISO 9001 certification unless a certification body has certified Hisham Nexus.
