# Hisham Nexus - Nonconformity / Complaint / CAPA Record

**Record No.:**  
**Date opened:**  
**Project / Client:**  
**Reported by:**  
**Type:** Nonconformity / Complaint / Correction / CAPA

## 1. Description
Describe the issue, affected deliverable, version, client impact, and how it was detected.

## 2. Immediate Control / Correction
- What was controlled?
- What was corrected?
- Was the client informed? Yes / No / N/A

## 3. Cause Review
- Direct cause:
- Root/contributing cause:
- Similar issue possible elsewhere? Yes / No / Details:

## 4. Corrective / Preventive Action
| Action | Owner | Due Date | Completion Date | Evidence |
|---|---|---|---|---|
|  |  |  |  |  |

## 5. Effectiveness Review
- Was the action effective? Yes / No
- Evidence:
- Further action needed:

**Closed by:**  
**Date closed:**  
