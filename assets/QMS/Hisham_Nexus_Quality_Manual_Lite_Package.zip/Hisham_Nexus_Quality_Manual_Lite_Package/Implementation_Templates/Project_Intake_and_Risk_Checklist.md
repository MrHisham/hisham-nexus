# Hisham Nexus - Project Intake and Risk Checklist

**Project Code:**  
**Client:**  
**Date:**  
**Prepared by:**  

## 1. Intake
- Client name and contact details:
- Project title / short description:
- Service type: Research / AI / Regulatory Writing / QMS / Training / Custom Resource / Other
- Purpose and intended use:
- Audience / recipient:
- Required deliverable format:
- Timeline and deadline drivers:
- Client materials required:

## 2. Confidentiality and Boundaries
- Confidential, unpublished, personal, or sensitive data? Yes / No / Details:
- NDA required before file sharing? Yes / No:
- Ethical, academic, regulatory, or institutional boundaries:
- Any claim that must be avoided or qualified:

## 3. Risk Review
| Risk Area | Low/Med/High | Controls Needed | Owner | Status |
|---|---|---|---|---|
| Scope clarity |  |  |  |  |
| Evidence/source limitations |  |  |  |  |
| Confidentiality/data protection |  |  |  |  |
| Ethics/academic integrity |  |  |  |  |
| Regulatory/professional limitations |  |  |  |  |
| Timeline/resource risk |  |  |  |  |
| AI-use risk |  |  |  |  |

## 4. Decision
Accept / Accept with controls / Request more information / Decline

**Decision rationale:**  
**Approved by:**  
