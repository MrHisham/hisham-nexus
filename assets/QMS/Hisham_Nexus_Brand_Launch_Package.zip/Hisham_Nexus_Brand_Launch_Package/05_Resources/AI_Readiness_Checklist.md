# AI Readiness Checklist

- [ ] What problem will AI solve?
- [ ] What data will be used and is it appropriate?
- [ ] Who is responsible for human oversight?
- [ ] What risks exist: bias, privacy, accuracy, overreliance, explainability?
- [ ] How will performance be monitored?
- [ ] Are ethical, legal, and institutional expectations addressed?
- [ ] Is there a training plan for users?
