# Scientific Presentation Structure

- [ ] Problem/context
- [ ] Why it matters
- [ ] Objective
- [ ] Method or approach
- [ ] Key findings
- [ ] Interpretation
- [ ] Limitations
- [ ] Practical implication
- [ ] Next steps
- [ ] One memorable conclusion
