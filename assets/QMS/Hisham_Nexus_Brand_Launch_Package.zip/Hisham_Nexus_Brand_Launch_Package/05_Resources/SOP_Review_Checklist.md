# SOP Review Checklist

- [ ] Does the SOP match the real workflow?
- [ ] Are responsibilities clear?
- [ ] Are materials/equipment/documents identified?
- [ ] Are steps written in logical order?
- [ ] Are acceptance criteria and records defined?
- [ ] Are deviations, risks, and exceptions handled?
- [ ] Is training required before implementation?
- [ ] Are references and version controls updated?
