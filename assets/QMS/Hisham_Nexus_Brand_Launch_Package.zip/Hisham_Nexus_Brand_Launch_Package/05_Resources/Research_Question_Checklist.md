# Research Question Checklist

- [ ] Is the research problem clear and specific?
- [ ] Is the target population defined?
- [ ] Is the outcome or variable measurable?
- [ ] Can the question be answered with available time, data, and resources?
- [ ] Is the question ethically appropriate?
- [ ] Does the question add value beyond what is already known?
- [ ] Can the question be converted into objectives or hypotheses?
