# Confidentiality / NDA Starter Template

Important: Have this reviewed by a qualified lawyer before formal use.

## Parties
Identify the disclosing party and receiving party.

## Purpose
Evaluation or delivery of consulting, research, writing, training, quality, regulatory, or digital adoption support.

## Confidential Information
Documents, data, research ideas, drafts, reports, methods, correspondence, project materials, commercial information, and unpublished work.

## Obligations
Use information only for the agreed purpose, protect it reasonably, and do not disclose it without permission.

## Exclusions
Information already public, independently developed, lawfully received from another source, or required to be disclosed by law.

## Return/Deletion
Return or delete materials upon request, subject to legal/administrative retention requirements.

## Term
Confidentiality obligations continue for a defined period, e.g., 3-5 years, or longer for trade secrets if applicable.

## No License
No ownership rights are transferred by sharing information.

## Governing Law
To be completed based on jurisdiction and legal advice.

## Signatures
Authorized representatives sign and date.
