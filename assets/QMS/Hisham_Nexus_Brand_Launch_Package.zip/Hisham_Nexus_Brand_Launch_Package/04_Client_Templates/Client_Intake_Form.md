# Hisham Nexus Client Intake Form

- Full name / organization / role
- Email and preferred contact method
- Project category: research, AI/digital health, quality, regulatory writing, training, custom resource, other
- What are you trying to achieve?
- Who is the intended audience or user?
- What output do you need? Document, review, training, checklist, presentation, report, advisory session, other
- Current stage: idea, draft, active project, revision, urgent issue, implementation
- Key background/context
- Files or materials available for review
- Deadline or preferred timeline
- Required standard, guideline, journal, institution, or regulatory context, if any
- Confidentiality sensitivity and whether an NDA is required
- Known limitations, assumptions, risks, or decisions already made
- Preferred language and tone
- Budget range or scope expectation, if available
- Decision-maker and approval process
